-- Your Pharmacy — Supabase schema
-- Supabase Dashboard → SQL Editor → New query → এটি পেস্ট করে Run চাপুন।

create table if not exists public.user_state (
  user_id    uuid        not null references auth.users(id) on delete cascade,
  k          text        not null,              -- 'state' বা মাসের বিক্রি, যেমন 's2026-10'
  data       jsonb       not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (user_id, k)
);

-- প্রত্যেক ব্যবহারকারী শুধু নিজের সারি দেখতে ও বদলাতে পারবে
alter table public.user_state enable row level security;

drop policy if exists "own select" on public.user_state;
drop policy if exists "own insert" on public.user_state;
drop policy if exists "own update" on public.user_state;
drop policy if exists "own delete" on public.user_state;

create policy "own select" on public.user_state for select to authenticated using (auth.uid() = user_id);
create policy "own insert" on public.user_state for insert to authenticated with check (auth.uid() = user_id);
create policy "own update" on public.user_state for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own delete" on public.user_state for delete to authenticated using (auth.uid() = user_id);

-- লগইন ছাড়া (anon) কোনো অ্যাক্সেস নেই
revoke all on public.user_state from anon;
grant select, insert, update, delete on public.user_state to authenticated;
