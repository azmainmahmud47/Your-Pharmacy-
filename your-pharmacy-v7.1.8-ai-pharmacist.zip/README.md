# Your Pharmacy v7.1.4 — Shared Generic Reference Database

## What changed (v7.1.4)
- AI assistant now answers dose, side effects, interactions, pregnancy and contraindication questions from the shared generic database.
- "&" generic names now match the database; duplicate records (same name) are both shown as Record 1/2, 2/2.
- Ledger (due/baki) dates are shown as mm/dd/yyyy in the app and in Excel/CSV exports.

## What changed (v7.1.3)
- v7.1.7: Added full product catalogs (name, strength, dosage form, MRP) for Incepta, Beximco, Renata, ACME, Eskayef and Healthcare from the supplied CSV/PDF files (5,174 products). The app now has 6,374 products and about 1,280 generics. Generic lists are cached for speed; long company/brand lists load 60 at a time.
- v7.1.6: Square Pharmaceuticals full catalog added (1013 products from the supplied PDF, with dosage form and MRP; entries are [name, generic, MRP, form]). 390+ new generic names appear in the Generics A–Z list; generics without a clinical record show no details card until their records are added to `data/generic-clinical-database.csv`.
- Added the supplied reviewed generic clinical CSV as a bundled, shared reference dataset under `data/generic-clinical-database.csv`, with the full Bangla translation in `data/generic-clinical-database-bn.json` (same order, 356 records; shown when the app language is Bangla). Every visitor receives the same version from the deployed site; it is not stored in an individual user's private shop state.
- Generic search now includes generic names from the full supplied file, not only the smaller built-in list.
- Generic detail pages show the additional clinical fields from the supplied database, with Bengali/English field labels following the selected language.
- Added version metadata and a shared-reference schema for generic, medicine, and AI knowledge tables.
- Existing customer, sales, stock, and shop data remain per-user. The reference database must not be mixed into a user's private inventory.

## Important language/clinical accuracy note
The source CSV's detailed clinical prose is English. In Bangla mode, the headings and explanatory UI are Bengali, but the source clinical text is intentionally preserved in English in this version. Automatically translating dosage, contraindications, pregnancy warnings, and drug interactions without clinical review can introduce dangerous errors. Do not represent this as a fully professionally translated Bengali clinical database. A fully Bengali clinical edition should be translated and reviewed by a qualified pharmacist before publication.

## Deploy
1. Extract the ZIP. Keep `index.html`, `config.js`, `schema.sql`, `icons/`, and `data/` together.
2. Deploy the folder to Netlify/Vercel. Do not upload only `index.html`; the `data` folder (CSV + Bangla JSON) must stay next to `index.html`.
3. `config.js` contains your existing public Supabase project URL and publishable key. Never add a service-role key to browser code.

## Supabase shared database (optional server-side mirror)
1. Run `schema.sql` in Supabase SQL Editor.
2. In Supabase Table Editor, import the source CSV into `generic_master` after mapping columns as follows: `Generic Name` → `generic_name`; `Therapeutic Class` → `therapeutic_class`; `Primary Indications (Detailed diseases/conditions)` → `primary_indications`; `Pharmacology & Mechanism of Action (How it works)` → `mechanism_of_action`; `Adult & Pediatric Dosage Instructions` → `dosage_instructions`; `Side Effects & Adverse Reactions` → `side_effects`; `Drug Interactions` → `drug_interactions`; `Contraindications` → `contraindications`; `Pregnancy & Lactation Safety Category` → `pregnancy_lactation`; `Precautions & Storage Conditions` → `precautions_storage`. Add `source_version` = `1.0` if the importer requires it.
3. `generic_master`, `medicine_master`, and `ai_knowledge_master` are shared reference tables with public read-only policies. Client users cannot change shared clinical data. Updating shared data should be an administrator-controlled, reviewed process.
4. The current browser UI loads the bundled CSV for dependable consistent results. The Supabase tables are a server-side mirror/schema and are not yet the live UI source; do not assume changes made only in Supabase will alter the bundled UI dataset until a later API integration.

## Safety
The CSV is a reference dataset, not a prescription engine. Doses depend on indication, formulation, age, weight, kidney/liver function, pregnancy, and local product labeling. Verify with authoritative product information before dispensing.


## v7.1.8 — AI Pharmacist
- Chat "+" now opens a menu: Camera, Photo (gallery), File (PDF/image/text).
- Prescription reader: image/PDF -> OCR (Tesseract.js, loaded from jsdelivr when needed; needs internet) -> medicines matched to the catalog with strength/form, qty, MRP, stock; editable text, alternatives, safety alerts, "Dispense" (records sale + deducts stock FIFO).
- Pharmacist consult: ~25 common conditions (fever, dengue, cold, cough, acidity, diarrhoea, pain, allergy, worms, fungal, wounds, burns, UTI, BP, diabetes, asthma, thyroid...) with self-care, OTC options + catalog brands, red-flag referral. No antibiotics/steroids without prescription.
- Audited-generics files (929 rows) were NOT merged: ~921 rows are template text.
